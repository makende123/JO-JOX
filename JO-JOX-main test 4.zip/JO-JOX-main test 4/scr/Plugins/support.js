module.exports = [
  {
    command: ['feedback'],
    operate: async ({ m, mess, text, jojox, isCreator, versions, prefix, command, reply, sendToTelegram }) => {
      if (!isCreator) return reply(mess.owner);
      if (!text) return reply(`Example: ${prefix + command} Hey dev, this bot is very awesome🔥`);

      const bugReportMsg = `
*USER FEEDBACK*

*User:* @${m.sender.split("@")[0]}
*Feedback:* ${text}

*Version:* ${versions}
      `;

      const confirmationMsg = `
Hi ${m.pushName},

Thanks for sharing your feedback with us. `;

      await sendToTelegram(bugReportMsg);
      jojox.sendMessage(m.chat, { text: confirmationMsg, mentions: [m.sender] }, { quoted: m });
    }
  },
  {
    command: ['reportbug'],
    operate: async ({ m, mess, text, jojox, isCreator, versions, prefix, command, reply, sendToTelegram }) => {
      if (!isCreator) return reply(mess.owner);
      if (!text) return reply(`Example: ${prefix + command} Hey, play command isn't working`);

      const bugReportMsg = `
*BUG REPORT*

*User:* @${m.sender.split("@")[0]}
*Issue:* ${text}

*Version:* ${versions}
      `;

      const confirmationMsg = `
Hi ${m.pushName},

Your bug report has been forwarded to my developer on Telegram.

*Details:*
${bugReportMsg}
      `;

      await sendToTelegram(bugReportMsg);
      jojox.sendMessage(m.chat, { text: confirmationMsg, mentions: [m.sender] }, { quoted: m });
    }
  },
  {
    command: ['request'],
    operate: async ({ m, mess, text, jojox, isCreator, versions, prefix, command, reply, sendToTelegram }) => {
      if (!isCreator) return reply(mess.owner);
      if (!text) return reply(`Example: ${prefix + command} I would like a new feature (specify) to be added.`);

      const requestMsg = `
*REQUEST*

*User:* @${m.sender.split("@")[0]}
*Request:* ${text}

*Version:* ${versions}
      `;

      const confirmationMsg = `
Hi ${m.pushName},

Your request has been forwarded to my developer on Telegram.

*Details:*
${requestMsg}
      `;

      await sendToTelegram(requestMsg);
      jojox.sendMessage(m.chat, { text: confirmationMsg, mentions: [m.sender] }, { quoted: m });
    }
},
{
  command: ["helpers", "support"],
  operate: async ({ m, args, reply }) => {
    const search = args.join(" ").toLowerCase();

    const filtered = global.helpersList.filter(helper =>
      !search || helper.country.toLowerCase().includes(search)
    );

    if (!filtered.length) {
      return reply(`❌ No helper found for "${search}".\nTry using: *.helpers* to see all.`);
    }

    filtered.sort((a, b) => a.country.localeCompare(b.country));

    let text = `*🌍 jojox Verified Helpers*\n\n`;
    filtered.forEach((helper, index) => {
      text += `${index + 1}. ${helper.flag} *${helper.country}*\n   • ${helper.name}: ${helper.number}\n\n`;
    });

    text += `✅ jojox Team\n`;
     https://t.me/josh_j_g\n`;
    text += `⚠️ Charges may apply depending on the service provided.`;

    reply(text);
  }
}
]